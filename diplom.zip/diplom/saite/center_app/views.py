from django.shortcuts import render

def index(request):
    return render(request, 'index.html')

def services(request):
    return render(request, 'services.html')

def doctors(request):
    return render(request, 'doctors.html')

def contacts(request):
    return render(request, 'contacts.html')

#<h1 <img class="inline-icon" src="{% static 'images/heart/png.png' %}"> class="text-center">Med~Cat</h1>
# Create your views here.
#007bff
#D3E2F1
