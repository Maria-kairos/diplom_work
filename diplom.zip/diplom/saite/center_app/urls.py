from django.urls import path
from center_app.views import index, services, doctors, contacts

urlpatterns = [
    path('', index, name='index'),
    path('services/', services, name='services'),
    path('doctors/', doctors, name='doctors'),
    path('contacts/', contacts, name='contacts'),
]